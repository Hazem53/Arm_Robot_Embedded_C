/*********************************************************************************
@Author-> Hazem Mohamed Hamdy
					Hamdy Aymen Hamdy
					Sara Srour Ahmed
					Ahmed Badr
					
@Project Title -> "The Last Dance of 8051 (Arm Robot)"
@Abstraction -> Using Embedded C  At89s51, ADC 0809 , SERVO MOTORS And 
								potentiometers we made an arm robot that can move Any 
								Piece From Place TO Another one .
								
@Date -> 11/5/2024
************************************************************************************/

#include "main.h"
uint8 index_1 = 0;
uint8 adc_value_flag;
uint8 button_flag;
uint8 value_adc[4];
uint8 temp[4];
int main()
{
	
	ADC0808_init();
	servo_motor_init();
	delay_ms(1000);
	while(1)
	{
		

			for(index_1 = 0;index_1 <4;index_1++)
			{
				temp[index_1] = adc_value_flag;
				Channel(index_1);
				start_conversion();
				monitor_flag();
				adc_value_flag = read_digital_signal();
				value_adc[index_1] = adc_value_flag;
			}

		if(value_adc[0] != temp[0])
		{
		servo_motor_degree(motor_1,value_adc[0]);
		}
		if(value_adc[1] != temp[1])
		{
		servo_motor_degree(motor_2,value_adc[1]);
		}
		if(value_adc[2] != temp[2])
		{
		servo_motor_degree(motor_3,value_adc[2]);
		}
		if(value_adc[3] != temp[3])
		{
		servo_motor_degree(motor_4,value_adc[3]);
		}
	}
}