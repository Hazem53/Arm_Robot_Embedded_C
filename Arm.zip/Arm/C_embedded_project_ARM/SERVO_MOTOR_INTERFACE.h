#ifndef SERVO_MOTOR_INTERFACE_H_
#define SERVO_MOTOR_INTERFACE_H_
#include "TIMER_INTERFACE.h"
#include "DIO_INTERFACE.h"
#define motor_1 P3_4
#define motor_2 P3_5
#define motor_3 P3_6
#define motor_4 P3_7
void servo_motor_init(void);
void servo_motor_degree(uint8 motor_pin,uint8 adc_value);

#endif