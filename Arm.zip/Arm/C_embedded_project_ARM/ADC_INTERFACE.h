#ifndef ADC_INTERFACE_H_
#define ADC_INTERFACE_H_
#include "DIO_INTERFACE.h"
/*  adc 0809-0808 pins*/
#define ADC_PORT P2
#define ALE      P1_0
#define SC       P1_1
#define EOC      P1_2
#define OE       P1_3
#define CLK      P1_4
#define A_C      P1_5
#define B_C      P1_6
#define C_C      P1_7
//==============================================
void ADC0808_init(void);
void Channel(uint8 channel);
void start_conversion(void);
void monitor_flag(void);
uint8 read_digital_signal(void);



#endif