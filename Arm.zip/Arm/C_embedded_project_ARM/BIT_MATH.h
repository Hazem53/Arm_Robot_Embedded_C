#ifndef BIT_MATH_H_
#define BIT_MATH_H_

//why we used macro function without usingg struct and pointers
//cuz keil prevents us from accessing the memory
#define SET_BIT(REG ,BIT) (REG |= (1<<BIT))
#define CLR_BIT(REG ,BIT) (REG &= ~(1<<BIT))
#define TOG_BIT(REG,BIT)  ((REG ^= (1<<BIT)))
#define GET_BIT(REG,BIT)  ((REG>>BIT) & 0x01)

#endif /* BIT_MATH_H_*/


/* COMMENT */
/*
SET_BIT(REG ,BIT) (REG |= (1<<BIT))
we give it required Register & pin_number we want to take 
action on it
==> is used to set one Bit inside Register
0011 0000 we want to set third Bit
after that we we will shift value (1) 3 timers to left
((1) << 3) ==> 0000 0100
then or gate this value with  0011 0000
0011 0000
0000 0100 OR GATE
=========
0011 0100
---------------------
CLR_BIT(REG ,BIT) (REG &= ~(1<<BIT))
we give it required Register & pin_number we want to take 
action on it
==> is used to clr one Bit inside Register
0011 0000 we want to clr  fifth Bit
to do that we are shifting value (1) with Bit position
we want to clr
(1<<5)  ==> 0001 0000
then make not for this value
~(1<<5) ==> 1110 1111
then make AND Gate for this value with Register
0011 0000
1110 1111 AND GATE
=========
0010 0000
---------------------
GET_BIT(REG,BIT)  ((REG>>BIT) & 0x01)
we give it required Register & pin_number we want to take 
action on it
===> its used to read required Bit value inside Register
0011 0000 we want to read fifth Bit
so we are gonna shift this Bit right by it position
(Register >> BIT) ==> 0000 0011
then AND GATE with value one
0000 0011
0000 0001 AND GATE
=========
0000 0001 ==> its value (1)
then its mean we are reading 5V (1) from fifth BIT
inside Register
*/