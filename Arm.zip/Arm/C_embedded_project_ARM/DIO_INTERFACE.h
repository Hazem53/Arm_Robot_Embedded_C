#ifndef DIO_INTERFACE_H_
#define DIO_INTERFACE_H_
#include <reg51.h>
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "delay.h"
#define PORT0 0
#define PORT1 1
#define PORT2 2
#define PORT3 3

#define P0_0 0
#define P0_1 1
#define P0_2 2
#define P0_3 3
#define P0_4 4
#define P0_5 5
#define P0_6 6
#define P0_7 7

#define P1_0 10
#define P1_1 11
#define P1_2 12
#define P1_3 13
#define P1_4 14
#define P1_5 15
#define P1_6 16
#define P1_7 17

#define P2_0 20
#define P2_1 21
#define P2_2 22
#define P2_3 23
#define P2_4 24
#define P2_5 25
#define P2_6 26
#define P2_7 27

#define P3_0 30
#define P3_1 31
#define P3_2 32
#define P3_3 33
#define P3_4 34
#define P3_5 35
#define P3_6 36
#define P3_7 37

#define OUTPUT 1
#define INPUT 0
#define HIGH 1
#define LOW 0


void pinMode(uint8 pin_num ,uint8 DIR);
void digitalWrite(uint8 pin_num ,uint8 STATE);
uint8 digitalRead(uint8 pin_num);

#endif /*�DIO_INTERFACE_H_�*/