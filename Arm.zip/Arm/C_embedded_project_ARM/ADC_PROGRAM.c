#include "ADC_INTERFACE.h"


void ADC0808_init(void)
{
	ADC_PORT =0xFF; //input
	pinMode(ALE,OUTPUT); //OUTPUT ADDRESS LATCH ENABLE
	pinMode(SC ,OUTPUT); //OUTPUT START OF CONVERSION
	pinMode(OE ,OUTPUT); //OUTPUT OUTPUT ENABLE
	pinMode(EOC,INPUT);  //INPUT  END OF CONVERSION FLAG
	pinMode(A_C,OUTPUT); //OUTPUT CHANNEL
  pinMode(B_C,OUTPUT); //OUTPUT CHANNEL
  pinMode(C_C,OUTPUT); //OUTPUT CHANNEL
	pinMode(CLK,OUTPUT); //OUTPUT CLK
}

//////////////////////
void Channel(uint8 channel)
{
	
	digitalWrite(A_C,(channel       &0x01));
	digitalWrite(B_C,((channel >>1) &0x01));
	digitalWrite(C_C,((channel >>2) &0x01));
}
//////////////////

void start_conversion(void){
	digitalWrite(ALE,HIGH);
	delay_ns(50);
	digitalWrite(SC,HIGH);
	delay_ns(50);
	digitalWrite(ALE,LOW);
	digitalWrite(SC,LOW);
}
void monitor_flag(void)
{
	while (digitalRead(EOC) == 1);
	while (digitalRead(EOC) == 0);
	
}
uint8 read_digital_signal(void)
{
	uint8 adc_value;
	digitalWrite(OE,HIGH);
	adc_value = ADC_PORT;
	digitalWrite(OE,LOW);
	
	return (adc_value);
}