// File: delay.c
#include <reg51.h>
#include "delay.h"

// Delay function using software loops
void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 120; j++); // Adjust this loop for 1ms delay based on your 8051 clock frequency
}


// Delay function in nanoseconds
void delay_ns(unsigned long ns) {
    unsigned long cycles_per_ns = CLOCK_FREQUENCY_HZ / 1000000000UL;
    unsigned long cycles_to_wait = ns * cycles_per_ns;

    // Adjust this loop for more precise timing
    while (cycles_to_wait--) {
        // No operation (NOP) assembly instruction
    }
}

