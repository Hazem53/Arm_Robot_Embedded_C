
#include "DIO_INTERFACE.h"
void pinMode(uint8 pin_num ,uint8 DIR)
{
	uint8 port;
	uint8 pin;
	port = pin_num/10; 
	pin = pin_num%10; 
	switch(DIR)
	{
		case INPUT:
			switch(port)
			{
				case PORT0:
				SET_BIT(P0,pin);
				break;
				case PORT1:
				SET_BIT(P1,pin);
				break;
				case PORT2:
				SET_BIT(P2,pin);
				break;
				case PORT3:
				SET_BIT(P3,pin);
				break;

			}
			break;
		case OUTPUT:
			switch(port)
			{
				case PORT0:
				CLR_BIT(P0,pin);
				break;
				case PORT1:
				CLR_BIT(P1,pin);
				break;
				case PORT2:
				CLR_BIT(P2,pin);
				break;
				case PORT3:
				CLR_BIT(P3,pin);
				break;
			}
			break;

	}
}
void digitalWrite(uint8 pin_num ,uint8 STATE)
{
	uint8 port;
	uint8 pin;
	port = pin_num/10;
	pin  = pin_num%10;
	switch(STATE)
	{
		case HIGH:
		switch(port)
		{
			case PORT0:
			SET_BIT(P0,pin);
			break;
			case PORT1:
			SET_BIT(P1,pin);
			break;
			case PORT2:
			SET_BIT(P2,pin);
			break;
			case PORT3:
			SET_BIT(P3,pin);
			break;

		}
		break;
		case LOW:
		switch(port)
		{
			case PORT0:
			CLR_BIT(P0,pin);
			break;
			case PORT1:
			CLR_BIT(P1,pin);
			break;
			case PORT2:
			CLR_BIT(P2,pin);
			break;
			case PORT3:
			CLR_BIT(P3,pin);
			break;
		}
		break;
	}
}
uint8 digitalRead(uint8 pin_num)
{
	uint8 flag = 0;
	uint8 port;
	uint8 pin;
	port = pin_num/10;
	pin  = pin_num%10;
	switch(port)
	{
		case PORT0:
		flag = GET_BIT(P0,pin);
		break;
		case PORT1:
		flag = GET_BIT(P1,pin);
		break;
		case PORT2:
		flag = GET_BIT(P2,pin);
		break;
		case PORT3:
		flag = GET_BIT(P3,pin);
		break;
	}
	return (flag);
}