#ifndef TIMER_INTERFACE_H
#define TIMER_INTERFACE_H
#include "DIO_INTERFACE.h"
#define mode0 0
#define mode1 1
/*
void Timer_0_init(uint8 mode);
void Timer_0(uint8 TH,uint8 TL);
*/
void Timer_1_init(uint8 mode);
void Timer_1(uint8 TH,uint8 TL);


#endif