#ifndef MAIN_H_
#define MAIN_H_
#include "ADC_INTERFACE.h"
#include "SERVO_MOTOR_INTERFACE.h"
#endif