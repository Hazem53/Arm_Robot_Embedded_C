#include <reg51.h>
#include "SERVO_MOTOR_INTERFACE.h"
void servo_motor_init(void)
{
	Timer_1_init(mode1);
	pinMode(motor_1,OUTPUT);
	pinMode(motor_2,OUTPUT);
	pinMode(motor_3,OUTPUT);
	pinMode(motor_4,OUTPUT);
	
	digitalWrite(motor_1,LOW);
	digitalWrite(motor_2,LOW);
	digitalWrite(motor_3,LOW);
	digitalWrite(motor_4,LOW);
	
	digitalWrite(motor_1,HIGH);
	Timer_1(0xFA,0x68); /// 1.5 ms
	digitalWrite(motor_1,LOW);
	Timer_1(0xB7,0xBC); //18.5ms
	delay_ms(10);
	
	digitalWrite(motor_2,HIGH);
	Timer_1(0xFA,0x68);
	digitalWrite(motor_2,LOW);
	Timer_1(0xB7,0xBC);
	delay_ms(10);
	
	digitalWrite(motor_3,HIGH);
	Timer_1(0xFA,0x68);
	digitalWrite(motor_3,LOW);
	Timer_1(0xB7,0xBC);
	delay_ms(10);
	
	digitalWrite(motor_4,HIGH);
	Timer_1(0xFA,0x68);
	digitalWrite(motor_4,LOW);
	Timer_1(0xB7,0xBC);
	delay_ms(10);
	
}



void servo_motor_degree(uint8 motor_pin,uint8 adc_value)
{
	digitalWrite(motor_1,LOW);
	digitalWrite(motor_2,LOW);
	digitalWrite(motor_3,LOW);
	digitalWrite(motor_4,LOW);
	
	if (adc_value <100)
	{
		//40 degree
		delay_ns(50);
		digitalWrite(motor_pin,HIGH);
		Timer_1(0xF9,0x50);
		digitalWrite(motor_pin,LOW);
		Timer_1(0xB9,0x09);
		delay_ns(50);
	}
	else if (adc_value >150)
	{
		//140 deg
		delay_ns(50);
		digitalWrite(motor_pin,HIGH);
		Timer_1(0xFB,0x80);
		digitalWrite(motor_pin,LOW);
		Timer_1(0xB6,0x6E);
		delay_ns(50);
	}
	else
	{ //90 deg
		delay_ns(100);
		digitalWrite(motor_pin,HIGH);
		Timer_1(0xFA,0x68);
		digitalWrite(motor_pin,LOW);
		Timer_1(0xB7,0xBC);
		delay_ns(100);
	}
	
}