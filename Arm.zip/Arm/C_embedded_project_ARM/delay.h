// File: delay.h

#ifndef DELAY_H
#define DELAY_H

// Function prototypes
void delay_ms(unsigned int ms);
void delay_ns(unsigned long ns);
#define CLOCK_FREQUENCY_HZ 12000000UL  // Example: 12 MHz
#endif // DELAY_H
