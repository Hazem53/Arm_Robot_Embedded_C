#include "TIMER_INTERFACE.h"
/*
void Timer_0_init(uint8 mode)
{
	switch(mode)
	{
		case mode0:
		TMOD &= 0xF0;
		TMOD |= 0x00;
		break;
		
		case mode1:
		TMOD &= 0xF0;
		TMOD |= 0x01;
		break;
		default: ;
		
	}
}
void Timer_0(uint8 TH,uint8 TL){
	TH0 = TH;
	TL0 = TL;
	TR0 = 1;
	while (TF0 == 0);
	TF0 = 0;
	TR0 = 0;
}
*/

void Timer_1_init(uint8 mode)
{
	switch(mode)
	{
		case mode0:
		TMOD &= 0x0f;
		TMOD |= 0x00;
		break;
		
		case mode1:
		TMOD &= 0x0F;
		TMOD |= 0x10;
		break;
		
		
	}
}
void Timer_1(uint8 TH,uint8 TL)
{
	TH1 = TH;
	TL1 = TL;
	TR1 = 1;
	while (TF1 == 0);
	TF1 = 0;
	TR1 = 0;
}